package com.ww.repository;

import com.ww.entity.Admin;

public interface AdminRepository {
    public Admin login(String username, String password);
}
