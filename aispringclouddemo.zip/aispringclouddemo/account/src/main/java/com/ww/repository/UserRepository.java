package com.ww.repository;

import com.ww.entity.User;

public interface UserRepository {
    public User login(String username, String password);
}
