package com.ww.repository;

import com.ww.entity.Type;

import java.util.List;

public interface TypeRepository {
    public Type findById(long id);
    public List<Type> findTypes();
}
