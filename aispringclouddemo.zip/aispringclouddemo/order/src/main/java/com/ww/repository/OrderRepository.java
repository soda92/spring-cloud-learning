package com.ww.repository;

import com.ww.entity.Order;

import java.util.List;

public interface OrderRepository {
    public void save(Order order);
    public List<Order> findAllByUid(int index, int limit,int uid);
    public int countByUid(int uid);
}
