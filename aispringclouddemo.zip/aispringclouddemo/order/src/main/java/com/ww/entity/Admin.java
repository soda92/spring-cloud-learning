package com.ww.entity;

import lombok.Data;

@Data
public class Admin {
    private long id;
    private String username;
    private String password;
}
