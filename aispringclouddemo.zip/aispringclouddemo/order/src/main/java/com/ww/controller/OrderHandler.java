package com.ww.controller;

import com.ww.entity.Order;
import com.ww.repository.OrderRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.Date;
import java.util.List;

//@RestController
@Controller
@RequestMapping("/order")
public class OrderHandler {
//    @Value("${server.port}")
//    private String port;
//    @GetMapping("/index")
//    public String index(){
//        return "order端口："+this.port;
//    }
    @Autowired
    private OrderRepository orderRepository;

    @PostMapping("/save")
    public void save(@RequestBody Order order){
        order.setDate(new Date());
        orderRepository.save(order);
    }
    @GetMapping("/findAllByUid/{index}/{limit}/{uid}")
    @ResponseBody
    public List<Order> findAllByUid(@PathVariable("index") int index,@PathVariable("limit") int limit,@PathVariable("uid") int uid){
        return orderRepository.findAllByUid(index,limit,uid);
    }
    @GetMapping("/countByUid/{uid}")
    @ResponseBody
    public int countByUid(@PathVariable("uid") int uid){
        return orderRepository.countByUid(uid);
    }

}
