package com.ww.controller;

import com.ww.entity.MenuVO;
import com.ww.entity.User;
import com.ww.entity.UserVO;
import com.ww.feign.UserFeign;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.Date;

@Controller
@RequestMapping("/user")
public class UserHandler {
    @Autowired
    private UserFeign userFeign;

    @GetMapping("/redirect/{location}")
    public String redirect(@PathVariable("location") String location){
        return location;
    }

    @GetMapping("/findAll")
    @ResponseBody
    public UserVO findAll(@RequestParam("page") int page, @RequestParam("limit") int limit){
        int index = (page-1)*limit;
        return userFeign.findAll(index,limit);
    }
    @GetMapping("/deleteById/{id}")
    public String deleteById(@PathVariable("id") long id){
        userFeign.delete(id);
        return "redirect:/user/redirect/user_manage";
    }
    @PostMapping("/save")
    public String save(User user){
        user.setRegisterdate(new Date());
        userFeign.save(user);
        return "redirect:/user/redirect/user_manage";
    }
    @GetMapping("/findById/{id}")
    @ResponseBody
    public User findById(@PathVariable("id") long id){
        return userFeign.findById(id);
    }
    @PostMapping("/update")
    @ResponseBody
    public void update(@RequestBody User user){
        userFeign.update(user);
    }
    @GetMapping("/count")
    @ResponseBody
    public int count(){return userFeign.count();}

}
