package com.ww.controller;

import com.ww.entity.Admin;
import com.ww.entity.User;
import com.ww.feign.AccountFeign;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpSession;
import java.util.LinkedHashMap;

@Controller
@RequestMapping("/account")
public class AccountHandler {
    @Autowired
    private AccountFeign accountFeign;
    @PostMapping("/login")
    public String login(@RequestParam("username") String username, @RequestParam("password") String password, @RequestParam("type") String type, HttpSession session){
        Object object=accountFeign.login(username,password,type);
        LinkedHashMap<String,Object> linkedHashMap=(LinkedHashMap<String, Object>) object;
        String result="";
        if(object==null){
            result="login";
        }else{
            switch (type){
                case "user":
                    long id=(Integer)linkedHashMap.get("id");
                    String nickname=(String)linkedHashMap.get("nickname");
                    User user=new User();
                    user.setId(id);
                    user.setNickname(nickname);
                    session.setAttribute("user",user);
                    result="index";
                    break;
                case "admin":
                    Admin admin=new Admin();
                    long aid=(Integer)linkedHashMap.get("id");
                    String ausername=(String)linkedHashMap.get("username");
                    admin.setId(aid);
                    admin.setUsername(ausername);
                    session.setAttribute("admin",admin);
                    result="menu_manage";
                    break;
            }
        }

        return result;
    }
    @GetMapping("/logout")
    public String logout(HttpSession session){
        session.invalidate();
        return "login";
    }
}
