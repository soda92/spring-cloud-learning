package com.ww.controller;

import com.ww.entity.User;
import com.ww.entity.UserVO;
import com.ww.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/user")
public class UserHandler {
    @Autowired
    private UserRepository userRepository;

    @GetMapping("/findAll/{index}/{limit}")
    public UserVO findAll(@PathVariable("index") int index,@PathVariable("limit")int limit){
        return new UserVO(0,"",userRepository.count(),userRepository.findAll(index,limit));
    }
    @DeleteMapping("/deleteById/{id}")
    public void deleteById(@PathVariable("id") long id){
        userRepository.delete(id);
    }
    @PostMapping("/save")
    public void save(@RequestBody User user){
        userRepository.save(user);
    }
    @GetMapping("/findById/{id}")
    public User findById(@PathVariable("id") long id){
        return userRepository.findById(id);
    }
    @PostMapping("/update")
    public void update(@RequestBody User user){
        userRepository.update(user);
    }
    @GetMapping("/count")
    public int count(){return userRepository.count();}
}
