package com.ww.repository;

import com.ww.entity.User;

import java.util.List;

public interface UserRepository {
    public List<User> findAll(int index, int limit);
    public int count();
    public void save(User user);
    public void update(User user);
    public void delete(long id);
    public User findById(long id);
}
