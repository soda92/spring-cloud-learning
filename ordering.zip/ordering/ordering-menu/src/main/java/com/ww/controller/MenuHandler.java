package com.ww.controller;

import com.ww.entity.Menu;
import com.ww.entity.MenuVO;
import com.ww.repository.MenuRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/menu")
public class MenuHandler {

    @Autowired
    private MenuRepository menuRepository;

//    @GetMapping("/findAll/{index}/{limit}")
//    public List<Menu> findAll(@PathVariable("index") int index,@PathVariable("limit") int limit){
//        return menuRepository.findAll(index,limit);
//    }

    @GetMapping("/findAll/{index}/{limit}")
    public MenuVO findAll(@PathVariable("index") int index, @PathVariable("limit") int limit){
        return new MenuVO(0,"",100,menuRepository.findAll(index,limit));
    }
}

