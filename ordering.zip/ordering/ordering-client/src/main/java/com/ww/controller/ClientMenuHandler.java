package com.ww.controller;

import com.ww.entity.Menu;
import com.ww.entity.MenuVO;
import com.ww.feign.MenuFeign;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/client")
public class ClientMenuHandler {
    @Autowired
    private MenuFeign menuFeign;
//    @GetMapping("/findAll/{index}/{limit}")
//    @ResponseBody
//    public List<Menu> findAll1(@PathVariable("index") int index, @PathVariable("limit") int limit){
//        return menuFeign.findAll(index,limit);
//    }
//    @GetMapping("/findAll")
//    @ResponseBody
//    public List<Menu> findAll(@RequestParam("page") int page, @RequestParam("limit") int limit){
//        int index = (page-1)*limit;
//        return menuFeign.findAll(index,limit);
//    }

    @GetMapping("/findAll")
    @ResponseBody
    public MenuVO findAll(@RequestParam("page") int page, @RequestParam("limit") int limit){
        int index = (page-1)*limit;
        return menuFeign.findAll(index,limit);
    }
    @GetMapping("/redirect/{location}")
    public String redirect(@PathVariable("location") String location){
        return location;
    }
}
